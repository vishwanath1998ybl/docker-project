# Project Docker Host Network
By following these step-by-step instructions, you'll gain hands-on experience with Docker host networking. Feel free to explore additional Docker networking features and commands to deepen your understanding further. Happy practicing!

# Run a Container on the Host Network
    docker run -d --name nginx_container --network host nginx

# Inspect the Host Network:
    docker network inspect host
This command will display detailed information about the host network, including connected containers.

# Stop and Remove Containers:
    docker stop nginx_container
    docker rm nginx_container

## 🟦🟦🟦🟦 TECH MAHATO || Search on YouTube 🟦🟦🟦🟦
### Participate Cloud & DevOps Pro. 100 Day Challenge & Win Rs. 5000/- Cash |
Ask Arbind Sir || WhatsApp 8100011825 || More Detailes: Visit https://devops.techmahato.com


```diff
+ AWS Cloud & DevOps Engineer is a trending skill for 2024-25 
```
Know More About Future of Cloud & DevOps | Visit: https://podcast.techmahato.com
