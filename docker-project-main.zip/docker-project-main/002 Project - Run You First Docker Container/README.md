# Project 2 : Run Your First Apache Web Server in Container
Login / SSH to Linux Server

Check Docker Status

Commands to Run Apache Web Server

    $ docker run httpd
  
Hit Public IP on Browser. Make sure httpd 80 & 443 port should be open.



## 🟦🟦🟦🟦 TECH MAHATO || Search on YouTube 🟦🟦🟦🟦
### Participate Cloud & DevOps Pro. 100 Day Challenge & Win Rs. 5000/- Cash |
Ask Arbind Sir || WhatsApp 8100011825 || More Detailes: Visit https://devops.techmahato.com


```diff
+ AWS Cloud & DevOps Engineer is a trending skill for 2024-25 
```
Know More About Future of Cloud & DevOps | Visit: https://podcast.techmahato.com


